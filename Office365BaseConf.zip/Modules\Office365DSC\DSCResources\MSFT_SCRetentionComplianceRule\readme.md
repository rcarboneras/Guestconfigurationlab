# SCRetentionComplianceRule

## Description

This resource configures a Retention Compliance Rule in Security and Compliance.
