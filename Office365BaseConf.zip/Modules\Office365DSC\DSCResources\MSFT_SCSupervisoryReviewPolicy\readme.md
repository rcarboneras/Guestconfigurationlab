# SCSupervisoryReviewPolicy

## Description

This resource configures a Supervision Policy in Security and Compliance.
