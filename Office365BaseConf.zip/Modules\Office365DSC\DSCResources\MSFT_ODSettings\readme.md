# ODSettings

## Description

This resource allows admins to manage blocked file types,
blocked domains and MAC Sync.
