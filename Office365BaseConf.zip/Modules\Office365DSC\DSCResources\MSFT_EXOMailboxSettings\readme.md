# Description

This resource configures settings on Mailboxes
such as the Regional settings and its timezone.
