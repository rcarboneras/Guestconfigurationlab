# Description

This resource is used to add new users to a team
