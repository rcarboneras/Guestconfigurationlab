For more information about Office365DSC and all of the resources,
including details and examples, please check out our
[Wiki](https://github.com/Microsoft/Office365DSC/wiki)
