
# SPO Tenant Settings

This resource allows users to configure and monitor the tenant settings for
their SPO tenant settings.
