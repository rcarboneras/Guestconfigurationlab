# Description

This resource is used to add and update channels in existing Teams.
