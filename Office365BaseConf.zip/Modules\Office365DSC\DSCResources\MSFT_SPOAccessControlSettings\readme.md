
# SPO Access Control Settings

This resource allows users to configure and monitor the access control settings for
your SPO tenant sharing settings.
