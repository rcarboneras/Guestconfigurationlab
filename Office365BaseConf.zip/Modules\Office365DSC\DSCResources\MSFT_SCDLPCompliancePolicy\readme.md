# SCDLPCompliancePolicy

## Description

This resource configures a Data Loss Prevention Compliance
Policy in Security and Compliance Center.
